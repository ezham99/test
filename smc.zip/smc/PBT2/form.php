<!DOCTYPE html>
<html>
<head>
    <title>Registration Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('er.jpg');
        }

        h1 {
            text-align: center;
        }

        form {
            max-width: 400px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-top: 10px;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        input[type="file"] {
            width: 100%;
            padding: 5px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .radio-group {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
        }

        .radio-group label {
            margin-right: 10px;
        }

        .radio-group input[type="radio"] {
            margin-right: 5px;
        }

        .radio-group.left-label label {
            margin-right: auto;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }

        #car_image {
            margin-bottom: 10px;
        }

        /* Styling for the attendee information section */
        fieldset.attendee-info {
            background-color: #eef5fb;
            padding: 10px;
            margin-bottom: 20px;
        }

        /* Styling for the car information section */
        fieldset.car-info {
            background-color: #f9eae8;
            padding: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1>Terengganu's Ertiga Club Tour Program Registration</h1>
    <form method="POST" enctype="multipart/form-data" action="register.php">
        <fieldset class="attendee-info">
            <legend>Attendee Information</legend>
            <label for="attendee_name">Name:</label>
            <input type="text" id="attendee_name" name="attendee_name" required>

            <div class="radio-group left-label">
                <label for="attendee_gender">Gender:</label>
                <label for="attendee_male"><input type="radio" id="attendee_male" name="attendee_gender" value="Male" required> Male</label>
                <label for="attendee_female"><input type="radio" id="attendee_female" name="attendee_gender" value="Female" required> Female</label>
            </div>

            <label for="attendee_phone">Phone Number:</label>
            <input type="tel" id="attendee_phone" name="attendee_phone" required>

            <label for="attendee_address">Address:</label>
            <textarea id="attendee_address" name="attendee_address" required></textarea>

            <label for="attendee_email">Email:</label>
            <input type="email" id="attendee_email" name="attendee_email" required>
        </fieldset>

        <fieldset class="car-info">
            <legend>Car Information</legend>
            <label for="car_year">Car Year:</label>
            <input type="text" id="car_year" name="car_year" required>
 
            <label for="car_color">Car Color:</label>
            <input type="text" id="car_color" name="car_color" required>

            <label for="car_image">Car Image:</label>
            <input type="file" id="car_image" name="car_image" required>
        </fieldset>

        <input type="submit" value="Submit" style="background-color: #4CAF50;">
    </form>
</body>
</html>
