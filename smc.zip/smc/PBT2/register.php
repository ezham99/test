 <?php
    // Define the directory to store the uploaded images
    $targetDirectory = "uploads/";

    // Function to handle file upload
    function uploadFile($fieldName)
    {
        global $targetDirectory;
        $targetFile = $targetDirectory . basename($_FILES[$fieldName]['name']);
        move_uploaded_file($_FILES[$fieldName]['tmp_name'], $targetFile);
        return $targetFile;
    }

    // Function to save participant details to a text file
    function saveParticipantDetails($data)
    {
        $file = fopen("participants.txt", "a");
        fwrite($file, $data);
        fclose($file);
    }

    // Check if the form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve form data
        $attendeeName = $_POST['attendee_name'];
        $attendeePhone = $_POST['attendee_phone'];
        $attendeeEmail = $_POST['attendee_email'];
        $attendeeAddress = $_POST['attendee_address'];
        $carYear = $_POST['car_year'];
        $carColor = $_POST['car_color'];
        $carImage = uploadFile('car_image');
        $attendeeGender = $_POST['attendee_gender'];

        // Prepare attendee details
        $attendeeDetails = "Attendee Name: $attendeeName\nPhone: $attendeePhone\nEmail: $attendeeEmail\nAddress: $attendeeAddress\nGender: $attendeeGender\n\n";

        // Prepare car details
        $carDetails = "Car Year: $carYear\nCar Color: $carColor\nCar Image: $carImage\n\n";

        // Save participant details to a text file
        saveParticipantDetails($attendeeDetails . $carDetails);

        echo "Registration successful!";
    } else {
        echo "Invalid request";
    }
    ?>