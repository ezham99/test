<!DOCTYPE html>
<html>
<head>
    <title>Order Coffee</title>
  
</head>
<header><h1>9.5 Coffee</h1></header>
<body>
    <style>

    body {
       
        background-image: url("coffe.jpg");
        font-family: fantasy;
    }

    button {
  color: white;
  padding: 0.7em 1.7em;
  font-size: 12px;
  border-radius: 0.5em;
  background: black;
  border: 1px solid #e8e8e8;
  transition: all .3s;

}

button:hover {
  border: 1px solid black;
}

button:active {
  box-shadow: 4px 4px 12px #c5c5c5,
             -4px -4px 12px #ffffff;
}

    </style>

    <?php
        
        $coffee_options = array(
            "Latte" => 7.00,
            "Cappuccino" => 8.00,
            "Espresso" => 6.50,
            "Americano" => 6.00,
            "Mocha" => 8.00,
            "Macchiato" => 9.00,
            "Iced coffee" => 8.00
        );

       
    ?>

    <form method="post" >
    <label for="name">Name:</label>
    <input type="text" name="name" id="name" required>    
    <br></br>

    <label for="phone">Phone Number:</label>
    <input type="tel" name="phone" id="phone" pattern="[0-9]{10}" required>

    <br></br>

    <label for="table">Table Number:</label>
    <input type="number" name="table" id="table" min="1" max="10" required>

    <br></br>

        <label1 for="coffee">Select coffee:</label1>
        <select name="coffee" id="coffee">
            <?php
               
                foreach($coffee_options as $option => $price) {
                    echo "<option value='$option'>$option ($price)</option>";
                }
            ?>
        </select>

        <br></br>

        <label2 for="quantity">Quantity:</label2>
        <input type="number" name="quantity" id="quantity" min="1" max="50" required>

        <br>
        <br>

    <label3>Choose Size:</label3>
    <input type="radio" name="size" id= "size" value="large" checked>Large
    <input type="radio" name="size"  id="size" value="small">Small

    <br>

        <br>

        <button type="submit" name="submit">Place Order</button></br>

    </form>
</body>
</html>
<?php
session_start();
if (isset($_POST["submit"])){
    $_SESSION["name"] = $_POST["name"];
    $_SESSION["coffee"] = $_POST["coffee"];
    $_SESSION["quantity"] = $_POST["quantity"];
    $_SESSION["size"] = $_POST["size"];
    $_SESSION["phone"] = $_POST["phone"];
    $_SESSION["table"] = $_POST["table"];
    header("Location: calculate.php");
}

?>